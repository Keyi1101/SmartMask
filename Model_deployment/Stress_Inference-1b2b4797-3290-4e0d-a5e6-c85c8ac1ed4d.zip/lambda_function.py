#This script is compatible with batch input/output
#Batch can be enabled by configuring DynamoDB strea batch_size
import json
import os
import sys
sys.path.append("/mnt/access/lib")
import numpy as np
from tensorflow import keras
from scipy.signal import resample
import boto3
import uuid

def lambda_handler(event, context):
    # TODO implement
    try:
        #instantiating classes
        model = keras.models.load_model("/mnt/access/model/CNN_Stress_1.h5")
        dynamodb = boto3.resource('dynamodb')
        table = dynamodb.Table('stress')
        
        #Extract event
        BVP = []
        ACCx = []
        ACCy = []
        ACCz = []
        TEMP = []
        stamp = []
        for records in event['Records']:
            #check if records contain new image
            try:
                image = records['dynamodb']['NewImage']
                BVP.append(np.array(json.loads(image['ppgred']['S']), dtype=np.float64))
                ACCx.append(np.array(json.loads(image['accelx']['S']), dtype=np.float64))
                ACCy.append(np.array(json.loads(image['accely']['S']), dtype=np.float64))
                ACCz.append(np.array(json.loads(image['accelz']['S']), dtype=np.float64))
                TEMP.append(np.array(json.loads(image['tresp']['S']), dtype=np.float64))
                stamp.append(image['time']['S'])
            except:
                pass
        
        #Preprocessing signals
        X = preprocessing({
            'BVP_in':BVP,
            'ACCx_in':ACCx,
            'ACCy_in':ACCy,
            'ACCz_in':ACCz,
            'TEMP_in':TEMP
        })
        
        #Make predictions
        y = model.predict(X)
        #print(y)
        #Write back results to Stress table
        with table.batch_writer() as batch:
            for i, t_stamp in enumerate(stamp):
                result = float(y[i])
                batch.put_item(Item={
                    "ID": str(uuid.uuid4()),
                    "stress": "{:.1%}".format(result),
                    "time": t_stamp
                })
                
        
        
    except Exception as e:
        print(e)
        return "Oops!"
    
    return {
        'statusCode': 200,
        'body': json.dumps('Hello from Lambda!')
    }
    
    

def preprocessing(in_stream):
    BVP = []
    ACCx = []
    ACCy = []
    ACCz = []
    TEMP = []
    
    for i in range(len(in_stream['BVP_in'])):
      #BVP
      b_tmp = in_stream['BVP_in'][i]
      b_tmp = (b_tmp - b_tmp.mean())/b_tmp.std()
      BVP.append(resample(b_tmp, 320))
      #ACC: nochange to range
      ACCx.append(resample(in_stream['ACCx_in'][i], 160))
      ACCy.append(resample(in_stream['ACCy_in'][i], 160))
      ACCz.append(resample(in_stream['ACCz_in'][i], 160))
      #TEMP
      t_tmp = in_stream['TEMP_in'][i]
      t_tmp = t_tmp/65536*165 + 40
      TEMP.append(resample(t_tmp, 20))

    return {
        'BVP_in':np.array(BVP)[:,:,np.newaxis],
        'ACCx_in':np.array(ACCx)[:,:,np.newaxis],
        'ACCy_in':np.array(ACCy)[:,:,np.newaxis],
        'ACCz_in':np.array(ACCz)[:,:,np.newaxis],
        'TEMP_in':np.array(TEMP)
    }
        